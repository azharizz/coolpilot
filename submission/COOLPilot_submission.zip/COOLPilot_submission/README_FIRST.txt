COOLPilot · OpenCV AI Competition 2026 submission package

COOLPilot_Technical_Report.pdf   technical report + Appendix A (agent workflow, traces) + Appendix B (COOL on Graviton)
sample_clips/                    two short clips to try the live Footage page (each under 5 MB)
  drivec_S07_night_clean.mp4     clean night clip -> expect "No camera-side problem flagged" + "Dark since the first frame"
  drivec_S02_blackout_fault.mp4  synthetic blackout fault -> expect a "near-black imagery" segment around 2.1-3.8 s
gallery/                         3:2 images (preview + real UI screenshots)
source/                          full source: coolpilot/ (detector, verifier, API), web/ (UI), experiments/, scripts/,
                                 deploy/aws/, tests/ (62), docs/ (incl. evidence/), video/ (showreel sources)

Live demo (read-only, AWS Lambda arm64): https://n7ebpehiuh2hczk2uzsherigia0pyqfg.lambda-url.us-east-1.on.aws/
Code: https://github.com/azharizz/coolpilot

Attribution: sample clips from DRIVE-C core v1 (Shiva Aher, Georgia Institute of Technology, doi:10.5281/zenodo.19656444),
CC BY 4.0; the blackout fault was added by COOLPilot. Road imagery in recordings: Oxford RobotCar Dataset
(Maddern et al., IJRR 2017), CC BY-NC-SA 4.0. Code: Apache-2.0.
