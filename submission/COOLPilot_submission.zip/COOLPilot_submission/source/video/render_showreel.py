"""Render showreel.html frame by frame.   python video/render_showreel.py [--stills t1,t2,...] [--fps 30]

Each frame awaits render(t) (footage frames are seeked, not played), then grabs the canvas as JPEG.
"""
import argparse
import base64
import pathlib
import subprocess

from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).parent
GRAB = "async t => { await render(t); return document.getElementById('c').toDataURL('image/jpeg', 0.94).split(',')[1]; }"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stills")
    ap.add_argument("--fps", type=int, default=30)
    args = ap.parse_args()
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--allow-file-access-from-files", "--force-color-profile=srgb", "--autoplay-policy=no-user-gesture-required"])
        pg = b.new_page(viewport={"width": 1920, "height": 1080})
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.goto((HERE / "showreel.html").as_uri())
        assert pg.evaluate("window.ready"), "Poppins failed to load"
        if args.stills:
            (HERE / "stills").mkdir(exist_ok=True)
            for t in args.stills.split(","):
                (HERE / "stills" / f"s{float(t):06.2f}.jpg").write_bytes(base64.b64decode(pg.evaluate(GRAB, float(t))))
            print("stills written", errors or "no page errors")
            return
        dur = pg.evaluate("DUR")
        ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "image2pipe", "-framerate", str(args.fps), "-i", "-",
                               "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p",
                               "-movflags", "+faststart", str(HERE / "showreel_silent.mp4")], stdin=subprocess.PIPE)
        n = round(args.fps * dur)
        for i in range(n):
            ff.stdin.write(base64.b64decode(pg.evaluate(GRAB, i / args.fps)))
            if i % 150 == 0:
                print(f"frame {i}/{n}", flush=True)
        ff.stdin.close()
        assert ff.wait() == 0
        print("done", errors or "no page errors")
        b.close()


if __name__ == "__main__":
    main()
