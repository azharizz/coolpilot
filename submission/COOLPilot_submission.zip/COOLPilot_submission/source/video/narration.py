"""Narration with the local Qwen3-TTS CustomVoice model (voice: Ryan). Writes vo/NN.wav and vo/lines.json.

    python video/narration.py            # every line
    python video/narration.py 3 7        # only these lines (after editing their text)

Each line has a target start time (seconds) in showreel.html; durations come back in lines.json so the
timeline can be checked. Every claim is from the evidence files (docs/BEFORE_AFTER.md, docs/COOL.md).
"""
import json
import sys
from pathlib import Path

import soundfile as sf
import torch
from qwen_tts import Qwen3TTSModel

HERE = Path(__file__).parent
SPEAKER = "Ryan"
STYLE = "Calm, confident male documentary narrator. Conversational and warm, natural pauses, medium pace, never rushed."
LINES = [
    (6.0, "Every camera on a car has bad days. A smear, a glare, a dark tunnel. And the worst part? It doesn't crash. It just quietly lies."),
    (17.5, "COOLPilot watches the camera itself. OpenCV 5 splits every frame into sixteen tiles, and learns what normal looks like for that camera. Its detail, its brightness, its sky."),
    (31.0, "When a tile drifts away from its own normal, that's a suspicion. Not an alarm. Not yet."),
    (39.5, "Here it is, live, on AWS Graviton. I start a replay of three cameras, and the centre one picks up glare as it happens."),
    (51.5, "But this tile looks blocked. So an agent steps in, and measures before it decides. Texture. Road users, with the new OpenCV 5 DNN engine. Motion. Open sky, nothing moving. That's the scene, not the lens. Dismissed."),
    (69.5, "On footage nobody had looked at, that second look took false alarms from two hundred and thirty two an hour, to zero. Without losing a single real fault."),
    (83.0, "You can screen your own recordings too. Drop in a clip, and it tells you what went wrong, and when. Night footage is treated as night, not as a broken camera."),
    (97.8, "And the detector can tune itself. A second agent diagnoses its own failures, runs ablations, and proposes a fix."),
    (106.5, "This one looked great on tuning data. A hundred and one clips caught, instead of seventy seven. Then it met footage it had never seen, and it failed. Nothing ships without fresh evidence and a human, so it never did."),
    (146.3, "Then, cool. We ran the whole workload on the cool image on Graviton. Kleidi C V, Arm Performance Libraries, every test passing, identical alarms."),   # spoken spelling: "COOL", "KleidiCV"
    (156.8, "And we let the numbers decide. Thirty cameras per instance on standard OpenCV 5. Twenty seven on cool. Thirty three on Intel, at a higher price. Per camera, Arm is the cheapest. So the pilot picks OpenCV 5, on Graviton."),
    (173.6, "What still fails is on screen too. Lens dirt, and part of the night. We'd rather show you that, than hide it."),
    (182.4, "Cool Pilot. Evidence, before recommendations."),   # spoken spelling of COOLPilot
    (122.8, "And OpenCV 5 pays off here. Its new graph engine runs our road user detector almost four times faster than OpenCV 4, on the same Arm machine, with identical results."),
    (134.3, "Setting up cool takes three steps. Launch its Graviton image, point Python at its OpenCV build, and run one thread per camera. Under load, it gave the steadiest latency."),
]


def main():
    only = {int(a) for a in sys.argv[1:]}
    out = HERE / "vo"; out.mkdir(exist_ok=True)
    device = "cpu"   # MPS fails in the speech decoder (conv1d with > 65536 output channels)
    name = "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice"   # 1.7B adds style instructions but is about 3x slower on CPU
    model = Qwen3TTSModel.from_pretrained(name, device_map=device, dtype=torch.float32)
    meta_path = out / "lines.json"
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    for i, (at, text) in enumerate(LINES):
        if only and i not in only:
            continue
        extra = {"instruct": STYLE} if "1.7B" in name else {}
        wavs, sr = model.generate_custom_voice(text=text, language="English", speaker=SPEAKER, **extra)
        sf.write(out / f"{i:02d}.wav", wavs[0], sr)
        meta[str(i)] = {"start": at, "duration": round(len(wavs[0]) / sr, 2), "text": text}
        print(f"{i:02d} start {at:6.1f}s  dur {meta[str(i)]['duration']:5.2f}s  ends {at + meta[str(i)]['duration']:6.1f}s", flush=True)
        meta_path.write_text(json.dumps(meta, indent=1))


if __name__ == "__main__":
    main()
