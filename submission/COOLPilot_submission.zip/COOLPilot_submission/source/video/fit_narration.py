"""Fit narration lines into their scene windows: trim silence, shorten long pauses, then, only if still needed,
speed up with pitch preserved (ffmpeg atempo, at most MAX_TEMPO). Writes vo/fit_NN.wav and vo/timeline.json.

    python video/fit_narration.py
"""
import json
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf

HERE = Path(__file__).parent
VO = HERE / "vo"
END, GAP, MAX_TEMPO, PAUSE = 189.3, 0.3, 1.22, 0.28


def tighten(x, sr):
    a = np.abs(x); thr = 0.02 * a.max(); win = int(0.02 * sr)
    loud = np.repeat([a[i:i + win].max() > thr for i in range(0, len(a), win)], win)[: len(a)]
    idx = np.where(loud)[0]
    x, loud = x[idx[0]: idx[-1] + 1], loud[idx[0]: idx[-1] + 1]
    out, i = [], 0
    while i < len(x):           # keep speech, cap every silent run at PAUSE seconds
        j = i
        while j < len(x) and loud[j] == loud[i]:
            j += 1
        seg = x[i:j]
        out.append(seg if loud[i] else seg[: int(PAUSE * sr)])
        i = j
    return np.concatenate(out)


def main():
    meta = json.loads((VO / "lines.json").read_text())
    rows = sorted(((int(k), v) for k, v in meta.items()), key=lambda kv: kv[1]["start"])
    timeline, prev_end = [], 0.0
    for n, (i, v) in enumerate(rows):
        x, sr = sf.read(VO / f"{i:02d}.wav")
        x = tighten(x, sr)
        nxt = rows[n + 1][1]["start"] if n + 1 < len(rows) else END
        window = nxt - v["start"] - GAP
        dur, tempo = len(x) / sr, 1.0
        raw = VO / f"tight_{i:02d}.wav"; sf.write(raw, x, sr)
        if dur > window:
            tempo = min(dur / window, MAX_TEMPO)
        out = VO / f"fit_{i:02d}.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(raw), "-filter:a", f"atempo={tempo:.4f}", str(out)], check=True)
        fdur = sf.info(out).duration
        at = max(v["start"], prev_end + 0.25)
        prev_end = at + fdur
        timeline.append({"line": i, "file": out.name, "at": round(at, 3), "dur": round(fdur, 2), "tempo": round(tempo, 3),
                         "target": v["start"], "window": round(window, 2), "late_s": round(at - v["start"], 2)})
        print(f"{i:02d} at {at:6.2f} (target {v['start']:6.1f})  {fdur:5.2f}s  tempo {tempo:.2f}  window {window:5.2f}")
    (VO / "timeline.json").write_text(json.dumps(timeline, indent=1))


if __name__ == "__main__":
    main()
