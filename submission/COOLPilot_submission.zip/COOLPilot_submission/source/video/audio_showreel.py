"""Soundtrack for showreel.html (178 s, 120 BPM, A minor): the original reel's instruments (audio.py),
arranged on the showreel timeline, ducked under the narration, then mixed with it.

    python video/audio_showreel.py          # needs vo/NN.wav + vo/lines.json (narration.py) and vo/timeline.json
"""
import json
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve, resample_poly

HERE = Path(__file__).parent
SR, BEAT, DUR = 48000, 0.5, 190.0
SC = {"intro": 0, "problem": 6, "sees": 17, "live": 39, "numbers": 69, "footage": 83, "pilot": 97.5, "opencv5": 122.5, "coolcfg": 134, "cool": 146, "honest": 173.5, "outro": 182}
CUTS = sorted(SC.values())[1:]
HITS = [14.3, 31.6, 65.4, 73.2, 127.9, 165.5]          # same as IMPACTS in showreel.html
REJECT, OUTRO = 113.9, 182.4
N = int(SR * DUR)
rng = np.random.default_rng(42)
mix, verb = np.zeros((2, N)), np.zeros((2, N))


def add(sig, at, gain=1.0, pan=0.0, send=0.0):
    i = int(at * SR)
    if i >= N or i < 0:
        return
    sig = sig[: N - i] * gain
    l, r = np.sqrt((1 - pan) / 2), np.sqrt((1 + pan) / 2)
    mix[0, i:i + len(sig)] += sig * l; mix[1, i:i + len(sig)] += sig * r
    if send:
        verb[0, i:i + len(sig)] += sig * l * send; verb[1, i:i + len(sig)] += sig * r * send


def tl(d): return np.arange(int(d * SR)) / SR
def filt(x, f, kind="low", order=2): return sosfilt(butter(order, f, kind, fs=SR, output="sos"), x)


def kick(big=False):
    t = tl(1.2 if big else 0.45); f = 42 + 110 * np.exp(-t * 28)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * (2.5 if big else 7))
    s += 0.25 * filt(rng.standard_normal(len(t)), 3000) * np.exp(-t * 120)
    return np.tanh(s * 1.6)
def hat(open_=False):
    t = tl(0.25 if open_ else 0.06); return filt(rng.standard_normal(len(t)), 7000, "high") * np.exp(-t * (14 if open_ else 70))
def clap():
    t = tl(0.35); n = filt(filt(rng.standard_normal(len(t)), 900, "high"), 4500)
    env = np.exp(-t * 16) + sum(np.exp(-np.maximum(t - d, 0) * 80) * (t >= d) for d in (0.0, 0.011, 0.022)) * 0.5
    return n * env + 0.3 * np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25)
def saw(f, d, voices=3, det=0.008):
    t = tl(d); return sum(2 * ((t * f * (1 + det * (v - voices // 2)) + rng.random()) % 1) - 1 for v in range(voices)) / voices
def whoosh(d=0.6, up=True):
    t = tl(d); n = rng.standard_normal(len(t)); env = np.sin(np.pi * t / d) ** 2; k = t / d if up else 1 - t / d
    return (filt(n, 600) * (1 - k) + filt(n, 4000) * k) * env
def riser(d):
    t = tl(d); f = 200 * np.exp(t / d * np.log(12)); tone = np.sin(2 * np.pi * np.cumsum(f) / SR)
    return (0.4 * tone + 0.6 * filt(rng.standard_normal(len(t)), 2500, "high")) * (t / d) ** 2
def impact():
    t = tl(2.5); sub = np.sin(2 * np.pi * np.cumsum(55 * np.exp(-t * 1.5) + 30) / SR) * np.exp(-t * 1.6)
    return np.tanh(1.8 * sub + 0.6 * filt(rng.standard_normal(len(t)), 5000) * np.exp(-t * 6))
def glitch(d=0.4):
    t = tl(d); out = np.zeros(len(t)); step = int(SR * 0.025)
    for i in range(0, len(t), step):
        seg = t[: min(step, len(t) - i)]; out[i:i + len(seg)] = np.sign(np.sin(2 * np.pi * rng.choice([110, 220, 880, 1760, 3520]) * seg)) * (rng.random() > 0.3)
    return filt(out, 6000) * (1 - t / d)
def tick():
    return filt(rng.standard_normal(200), 5000, "high") * np.exp(-tl(200 / SR) * 300)


ROOTS = [55.0, 43.65, 65.41, 49.0]
CHORDS = [[220, 261.6, 329.6], [174.6, 220, 261.6], [261.6, 329.6, 392], [196, 246.9, 293.7]]
def section(t): return max(k for k, v in SC.items() if v <= t) if False else [k for k, v in sorted(SC.items(), key=lambda kv: kv[1]) if v <= t][-1]
DROP = (173.5, 182.0)                       # "what still fails": pad only
ROLL = (REJECT - 1.0, REJECT)

# intro: the original logo hits
for h in (0.5, 1.0, 1.5):
    add(kick(True), h, 0.9, send=0.3); add(clap(), h, 0.35, send=0.5)
add(riser(0.5), 0.0, 0.25); add(whoosh(0.5), 1.6, 0.35, send=0.3)

# drums: density follows the story
t = SC["problem"]
while t < OUTRO - 1e-9:
    sec, b = section(t), round(t / BEAT)
    quiet = DROP[0] <= t < DROP[1] or ROLL[0] <= t < ROLL[1]
    half = sec == "pilot" and t < REJECT
    if not quiet and not (half and b % 2) and sec != "problem" or (sec == "problem" and b % 4 == 0):
        add(kick(), t, 0.85 if sec in ("live", "cool", "footage", "opencv5", "coolcfg") else 0.7)
    for off in ((0.25,) if sec in ("problem", "sees", "honest") else (0.125, 0.25, 0.375)):
        tt = t + off
        if not (DROP[0] <= tt < DROP[1]) and tt < OUTRO:
            add(hat(off == 0.25), tt, 0.13 if off == 0.25 else 0.055, pan=0.3 if off == 0.25 else -0.3)
    if sec in ("live", "cool", "footage", "opencv5", "coolcfg") and b % 2 == 1 and not quiet:
        add(clap(), t, 0.4, send=0.35)
    t += BEAT
for i in range(32):
    add(clap(), ROLL[0] + 1.0 * (1 - (1 - i / 32) ** 1.6), 0.1 + 0.28 * i / 32, send=0.2)

# bass: offbeat 8ths from "how it sees"
t = SC["sees"]
while t < OUTRO - 1e-9:
    if not (DROP[0] <= t < DROP[1]):
        f = ROOTS[int(t // 2) % 4] * (2 if int(t * 4) % 4 == 3 else 1)
        bright = 1700 if section(t) in ("live", "cool") else 950
        add(filt(saw(f, 0.24, 2), bright) * np.exp(-tl(0.24) * 9), t + 0.25, 0.45)
    t += BEAT

# pad through everything, opening up in the big sections
for bar in range(int(OUTRO // 2)):
    t0, d = bar * 2.0, 2.2
    p = sum(saw(f, d, 3, 0.006) for f in CHORDS[bar % 4]) / 3
    p = filt(p, 2200 if section(t0) in ("live", "cool", "honest") else 1200) * np.minimum(1, tl(d) / 0.3) * np.minimum(1, (d - tl(d)) / 0.3)
    add(p, t0, 0.2, send=0.6)
fin = sum(saw(f, DUR - OUTRO, 4, 0.01) for f in [110, 220, 261.6, 329.6, 440]) / 5
add(filt(fin, 2400) * np.exp(-tl(DUR - OUTRO) * 0.5), OUTRO, 0.3, send=0.8)

# transitions (the RGB wipe enters ~0.34 s before each cut)
for c in CUTS:
    add(whoosh(0.7), c - 0.5, 0.45, pan=-0.4, send=0.2); add(whoosh(0.7, False), c - 0.35, 0.28, pan=0.4)
for h in HITS:
    add(kick(True), h, 0.6, send=0.3); add(clap(), h, 0.3, send=0.5)
add(riser(1.0), REJECT - 1.0, 0.4); add(impact(), REJECT, 1.0, send=0.5)
add(glitch(0.45), REJECT, 0.25, pan=-0.5); add(glitch(0.35), REJECT + 0.1, 0.2, pan=0.5)
add(glitch(0.3), 14.3, 0.2, pan=0.4)
add(riser(1.2), OUTRO - 1.2, 0.35); add(impact(), OUTRO, 0.9, send=0.6)
for h in (0, 0.12, 0.24):
    add(clap(), OUTRO + h, 0.3, send=0.7)
# UI ticks: cursor clicks, typing in the trace and the COOL terminal
for at in (SC["live"] + 3.0, SC["footage"] + 2.2, SC["footage"] + 3.5):
    add(tick(), at, 0.35)
for a, b in ((SC["pilot"] + 0.4, SC["pilot"] + 8.0), (SC["cool"] + 0.6, SC["cool"] + 7.5)):
    for t in np.arange(a, b, 0.0625):
        if rng.random() < 0.4:
            add(tick(), t, 0.06, pan=rng.uniform(-0.6, 0.6))

ir_t = tl(2.2)
ir = filt(np.stack([rng.standard_normal(len(ir_t)) * np.exp(-ir_t * 2.6) for _ in range(2)]), 5000) * 0.06
mix += np.stack([fftconvolve(verb[i], ir[i])[:N] for i in range(2)])
mix = np.tanh(filt(mix, 28, "high") * 0.9)
mix /= np.abs(mix).max() / 0.89

# ---- narration: place lines on the timeline, duck the music under them ----
timeline = json.loads((HERE / "vo" / "timeline.json").read_text())
vo = np.zeros(N)
for row in timeline:
    sr, x = wavfile.read(HERE / "vo" / row["file"])
    x = x.astype(np.float64) / (32768 if x.dtype == np.int16 else 1)
    if x.ndim > 1:
        x = x.mean(axis=1)
    if sr != SR:
        x = resample_poly(x, SR, sr)
    i = int(row["at"] * SR); x = x[: N - i]
    vo[i:i + len(x)] += x
vo /= max(np.abs(vo).max(), 1e-9) / 0.92
env = np.convolve((np.abs(vo) > 0.02).astype(float), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same")
duck = 1 - 0.62 * np.clip(env * 4, 0, 1)                      # about -8 dB under speech, eased in and out
final = mix * duck * 0.72 + np.stack([vo, vo]) * 0.95
fade = int(0.8 * SR); final[:, -fade:] *= np.linspace(1, 0, fade) ** 2
final /= np.abs(final).max() / 0.95
wavfile.write(HERE / "showreel_audio.wav", SR, (final.T * 32767).astype(np.int16))
print("showreel_audio.wav written")
