# COOLPilot desktop workspace

Mode: Operate. Solo implementation as requested.

THESIS: Start a real optimization with no required edits, then see whether its validated result is worth applying.
VISUAL REFERENCE: The user selected OpenCV's website. Use Poppins, black navigation and start surface, white content, blue actions and an RGB-inspired COOLPilot mark. Reference screenshot: review/revamp/opencv-reference.png.
FLOW: Optimize in one click, inspect the held-out comparison, apply a passing recommendation, or reuse the run. Advanced setup and diagnostic evidence remain accessible through native details and separate views.
FIRST VIEWPORT: Optimize shows the primary action and the real workload. A saved run shows its outcome, before/after comparison and the start of tracking evidence.
LISTS: Three recent runs. Server-paginated full history with search and status filters, eight rows per page. Experiments use six rows per page; reasoning uses four entries per page.
FINISH: Desktop only. Complete implementation before compilation and visual inspection. Unit, integration and live benchmark tests remain deferred at the user's request. Screenshots and review results are recorded in UX_REVAMP.md. The previous rail/ledger design is superseded.
